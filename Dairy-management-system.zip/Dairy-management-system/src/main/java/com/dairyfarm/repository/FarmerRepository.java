package com.dairyfarm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.dairyfarm.model.Farmer;

public interface FarmerRepository extends JpaRepository<Farmer, Long> {
    Farmer findByRegisteredNo(String registeredNo);
}
