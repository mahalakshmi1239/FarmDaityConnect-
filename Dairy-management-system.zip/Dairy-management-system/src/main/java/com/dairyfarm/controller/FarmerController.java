package com.dairyfarm.controller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.dairyfarm.model.Farmer;
import com.dairyfarm.repository.FarmerRepository;

@Controller
public class FarmerController {

    @Autowired
    private FarmerRepository farmerRepository;

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("farmer", new Farmer());
        return "register";
    }

    @PostMapping("/register")
    public String registerFarmer(Farmer farmer, Model model) {
        farmer.setRegistrationDate(LocalDate.now());
        
        // Save the farmer to generate the ID
        farmerRepository.save(farmer);
        
        // Set the registeredNo as the ID (converted to String)
        farmer.setRegisteredNo(String.valueOf(farmer.getId()));
        
        // Save again to store the registeredNo
        farmerRepository.save(farmer);
        
        // Pass the farmer's name and registeredNo to the thank-you page
        model.addAttribute("farmerName", farmer.getName());
        model.addAttribute("registeredNo", farmer.getRegisteredNo());

        return "thank-you"; // Render the thank-you page
    }

    @GetMapping("/login")
    public String showLoginForm(Model model) {
        model.addAttribute("farmer", new Farmer());
        return "login";
    }

    @PostMapping("/login")
    public String loginFarmer(Farmer farmer, Model model) {
        // Find farmer by registeredNo instead of Id
        Farmer existingFarmer = farmerRepository.findByRegisteredNo(farmer.getRegisteredNo());
        if (existingFarmer != null) {
            existingFarmer.setMilkQuantity(farmer.getMilkQuantity());
            existingFarmer.setSnf(farmer.getSnf());
            existingFarmer.setFatPercentage(farmer.getFatPercentage());
            existingFarmer.setTotalAmount(existingFarmer.getMilkQuantity() * existingFarmer.getFatPercentage());
            farmerRepository.save(existingFarmer);
            model.addAttribute("message", "Details saved successfully!");
        } else {
            model.addAttribute("error", "Farmer not found!");
        }
        return "login";
    }
}
